# External QA Source Spot Checks

Checked: 2026-08-15

These are QA spot checks, not a replacement for the workers' source registers.

## Research 4

- PlanSwift checkout: https://www.planswift.com/checkout/ — observed US$2,000 annual subscription.
- PlanSwift trial FAQ: https://www.planswift.com/trial-submission/ — observed US$1,749/year/license. The contradiction is therefore live and correctly preserved by Research 4.
- Purdue CIB abstract: https://docs.lib.purdue.edu/cib-conferences/vol1/iss1/74/ — reports 94.1% accuracy in automatic area calculation and about 99% time reduction for the tested irregular-area task.
- STACK pricing: https://www.stackct.com/t-e-pricing-monthly-price-default/ — observed Premium US$249 and Pro US$299 per user/month, billed annually.

## Research 5

- PMC article: https://pmc.ncbi.nlm.nih.gov/articles/PMC7651899/ — title `Automation bias and verification complexity: a systematic review`; authors David Lyell and Enrico Coiera. This confirms the S31 author-field defect.

## Research 6

First-party GitHub connector spot checks confirmed the existence/content category of commits recorded in `QA_FINDINGS.json`.
