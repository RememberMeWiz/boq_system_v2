# Research B Wave 4 QA Review R1

Project: `boq_system_v2`  
Lane: Research B  
Route: `Research 4/5/6 -> Research B TL -> Research B QA -> PM`  
QA date: `2026-08-15`

## QA decision

**Overall verdict:** `QA_PASS_WITH_NOTES`  
**Routing status:** `READY_FOR_PM`

The three worker submissions are suitable for PM review. No QA finding invalidates a primary conclusion, defeats the focused corrections accepted by Research B TL, or requires another worker backjob before PM review.

The remaining findings are traceability and implementation-hardening notes. They should be preserved in PM/archival records rather than silently discarded.

## Inputs and integrity

Reviewed handoff archive:

- `RESEARCH_B_WAVE4_TECH_REVIEW_R1.zip`
- SHA-256: `b8b9c46b6b51de14526b4ce28975230581272fa056596bf37cb844b21c6f5c0d`

Nested worker archives independently matched the TL chain of custody:

- Research 4: `f5cb56df705567109fdd0dd577b1ce94f6b883910153794935935492eb432e3f`
- Research 5: `c9d0091fe7a2a32c3b6defc79448bd6b61aab9d86da583547ebb0019c78f0903`
- Research 6: `2a5294733917a71c5819995b189c82c0edd7fa1b93cffd296a11c98c9037233e`

The outer `SHA256SUMS.txt` and all three worker internal checksum sets were independently rechecked successfully. Worker validators were treated only as supporting evidence, not as QA proof.

## Worker verdicts

| Worker | Task | QA verdict | PM readiness |
|---|---|---|---|
| Research 4 | `R4-MARKET-001` | `QA_PASS_WITH_NOTES` | `READY_FOR_PM` |
| Research 5 | `R4-UX-001` | `QA_PASS_WITH_NOTES` | `READY_FOR_PM` |
| Research 6 | `R4-PROCESS-001` | `QA_PASS_WITH_NOTES` | `READY_FOR_PM` |

## Research 4 independent QA

### What held up

1. **Evidence classes are materially separated.** Independent recount reproduced 380 capability claims: 248 `DOCUMENTED_FEATURE`, 107 `UNVERIFIED`, 19 `VENDOR_CLAIM`, 5 `INDEPENDENT_OBSERVATION`, and exactly 1 `BENCHMARKED_RESULT`.
2. **The retained benchmark is correctly narrow.** `CLM-0366` is tied to Purdue/CIB source `S059`. The official abstract reports 94.1% automatic area-calculation accuracy and about 99% time reduction for the tested irregular-area task. The worker explicitly prevents generalization beyond that experiment.
3. **Pricing contradiction handling is evidence-grade.** PlanSwift currently exposes two conflicting official public prices: US$2,000 on the checkout page and US$1,749/year/license on the trial FAQ. The submission records both and does not silently resolve the conflict.
4. **Competitor-absence language is appropriately bounded.** The strategic conclusion is framed as what the review did or did not find in public evidence, not proof that competitors lack unpublished capabilities.
5. **Commercial-benchmark limitation is preserved.** The package does not claim a hands-on commercial-product accuracy benchmark that was not actually performed.

### QA note R4-N1: STACK pricing basis should be tightened on the next source refresh

The stored pricing snapshot records STACK Premium at US$249 and Pro at US$299 with billing basis `per month`, marks them non-comparable, and says user/seat interpretation should be confirmed. Current official pricing is more specific: **per user / month, billed annually** for those displayed prices.

Impact: minor provenance precision issue only. It does not affect the package's strategic conclusion because STACK is excluded from the simple seat-comparison claim and the row is already marked non-comparable.

Recommended archival action: on the next market-source refresh, store `per user/month, billed annually` explicitly and retain the observation date.

## Research 5 independent QA

### What held up

1. **The focused state-model contradiction is closed.** `origin`, `evidence_health`, `review_state`, lifecycle, change provenance, override status, and solver gate are independent axes rather than overloaded labels.
2. **Missing/conflicting evidence is not converted into supported evidence by a manual override.** The model preserves the original evidence state and creates `eligible_by_authorized_override` only when explicit policy, current authorization, and required review confirmation permit it.
3. **Solver eligibility is policy-derived.** The research does not quietly invent final business policy for which claim classes may proceed by override.
4. **Correction, rejection, supersession, and authorization histories are kept conceptually distinct.** The worked examples demonstrate the intended semantics rather than relying on prose alone.
5. **UX superiority is not claimed as measured fact.** The synchronized workbench is presented as a qualitative research direction pending estimator/prototype validation.
6. **External human-factors/accessibility sources support the interaction principles at the level claimed.** The package generally keeps adjacent-domain evidence from being presented as construction-specific performance proof.

### QA note R5-N1: source `S31` author attribution is wrong

`S31` identifies the paper **Automation bias and verification complexity: a systematic review** as `Goddard et al.`. The cited PMC article is authored by **David Lyell and Enrico Coiera**. Goddard and colleagues authored a different automation-bias systematic review.

Impact: source-metadata/provenance defect. The URL, paper title, and underlying evidence are real and still support the limited human-factors risk framing used by the package, so the affected qualitative conclusion does not collapse.

Required record correction before treating the source register as archival-final: change the `system_or_author` field for `S31` to `David Lyell and Enrico Coiera` and synchronize `SOURCE_NOTES/S31.md`. No fresh UX research or worker rerun is required.

### QA note R5-N2: make `ambiguous` explicitly fail-closed in implementation policy

The evidence-health enum includes `ambiguous`, defined as evidence that exists but cannot be assigned uniquely. The most explicit solver-gate and override examples focus on `missing` and `conflicting` evidence.

Impact: no demonstrated current contradiction, but there is an implementation ambiguity worth removing before code is written.

Recommended implementation invariant: solver-critical `ambiguous` evidence remains blocked unless an explicit policy exception exists, and any exception must preserve `evidence_health=ambiguous` rather than relabeling it `supported`.

## Research 6 independent QA

### What held up

1. **The reconstructed counts recompute.** The package contains 32 workflow events, 13 curated backjob/root-cause records, 19 verification activities, and 20 recommendations.
2. **The 142 recheck figure is transparent arithmetic, not fake time accounting.** It is explicitly composed of 73 full revalidation rows + 68 second-pass rows + 1 single-record closure. The report does not convert those 142 row-level actions into invented labor hours.
3. **The TL split is not sold as proven productivity.** Six-worker fan-in to one TL versus three-worker fan-in per A/B TL yields a 50% structural fan-in reduction. The package explicitly states that post-split throughput has not yet been measured.
4. **Backjob attribution is bounded.** The 13-row register is treated as a curated observed set rather than a claim that every historical backjob was captured.
5. **Automation recommendations preserve authority.** Independent QA and PM gates remain human-owned; archive automation prepares accepted artifacts and does not auto-push/adopt them.
6. **First-party repository spot checks corroborate process claims.** The cited Solver baseline restoration, audit restoration, and golden-beam commits exist. The cited `b922d2a2...` follow-up commit changes only trailing whitespace in three baseline-report metadata lines, supporting the package's low-value late-formatting example.

### QA note R6-N1: historical internal-source portability is incomplete

Several source-register entries (`S004` through portions of the correction/governance lineage) point to `project file retrieval`, previously uploaded documents, or earlier extracted package paths rather than embedding those source artifacts or recording a preservation hash for each one in this Wave 4 archive.

Impact: the claim/evidence matrices are usable now, but a future independent auditor holding only this worker ZIP could not reconstruct every historical source observation from the package alone. This is a reproducibility ceiling, not evidence that the process conclusions are false.

Recommended future packaging rule: for internal project sources that cannot be embedded, preserve at least filename/document identity, content SHA-256, originating package/handoff ID, and stable repository or archive receipt where one exists.

## Cross-worker synthesis QA

The TL synthesis is supported at the level stated:

- automatic takeoff and visual linking have market precedent;
- a more defensible product direction is evidence-complete, reviewable, fail-closed, reproducible drawing-to-BOQ reasoning;
- UX should preserve uncertainty and distinguish evidence from authorized human decisions;
- process redesign should be measured longitudinally before productivity claims are made;
- vendor documentation should not be promoted into independent benchmark evidence.

No cross-team conflict requiring Research A arbitration was identified in this review.

## PM-facing disposition

`QA_PASS_WITH_NOTES`

`READY_FOR_PM`

PM can evaluate/adopt the Research B Wave 4 findings without another worker backjob. For archival quality, carry forward these three concrete cleanup/hardening items:

1. tighten STACK billing-basis provenance at the next market refresh;
2. correct Research 5 `S31` author metadata and make `ambiguous` explicitly fail-closed in implementation policy;
3. improve hash/receipt portability for Research 6 historical internal sources.

None of these notes should be misrepresented as proof of commercial-product benchmark accuracy, estimator usability improvement, or process throughput improvement. Those remain explicitly unmeasured.
