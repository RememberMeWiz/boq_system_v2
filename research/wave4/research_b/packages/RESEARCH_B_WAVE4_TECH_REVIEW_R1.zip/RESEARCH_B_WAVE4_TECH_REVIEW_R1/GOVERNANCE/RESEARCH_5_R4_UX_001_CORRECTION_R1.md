# Research 5 — R4-UX-001 Focused Correction R1

## Role and routing

Worker: **Research 5**

Task:

```text
R4-UX-001
Estimator Review and Visual Provenance UX
```

Routing remains:

```text
Research 5
→ Research B TL
→ Research B QA
→ PM
```

This is a **focused semantic-model and decision-matrix correction only**. Do not restart the UX study or add volume for its own sake.

## TL review result

Status:

```text
TL_RETURNED_FOR_FOCUSED_CORRECTION_R1
```

The R1 package is structurally strong. Research B TL independently confirmed the package hashes and the reported counts of 35 sources, 46 UX patterns, 26 failure scenarios, 7 worked journeys, and 22 review metrics.

The synchronized review-workbench direction is not being rejected.

## Required correction 1 — make the review-state model genuinely orthogonal

`EVIDENCE/REVIEW_STATE_MODEL.md` and `EVIDENCE/review_state_model.json` currently define:

```text
review_disposition =
unreviewed | review_required | confirmed | rejected | corrected | overridden
```

This conflicts with the package's own required states and journeys.

Examples:

- a corrected claim may later be confirmed;
- a manual override may be confirmed;
- the package explicitly renders `Manual override · confirmed`;
- `J04_missing_override.md` describes a manual/overridden claim while later review/authorization can still exist.

If `corrected`, `overridden`, and `confirmed` are mutually exclusive members of one enum, those combinations cannot be represented without losing information.

### Required repair

Refactor the model so that review approval/disposition is separate from correction/override provenance.

A defensible form would be conceptually similar to:

```text
origin:
observed | derived | manual

evidence_health:
supported | conflicting | missing | ambiguous

review_state:
unreviewed | review_required | confirmed | rejected

lifecycle:
current | superseded

change/provenance:
represented by immutable correction / override / reassignment events
or by a separate non-conflicting axis if a current-state projection is required
```

The exact names may differ, but the model must be able to represent at least:

```text
manual + missing + confirmed-via-authorized-override + current
corrected + review_required + current
corrected + confirmed + current
derived + conflicting + review_required + current
observed + supported + confirmed + superseded
```

without overwriting historical meaning.

## Required correction 2 — clarify override versus missing evidence

A manual override must not silently turn missing drawing evidence into `supported`.

Clarify the current-state and history semantics for:

- original missing condition;
- manual value origin;
- override authorization;
- reviewer confirmation;
- stale/re-review trigger;
- solver eligibility under an explicitly authorized override policy.

Update at minimum:

- `EVIDENCE/REVIEW_STATE_MODEL.md`;
- `EVIDENCE/review_state_model.json`;
- `EVIDENCE/CORRECTION_WORKFLOW.md`;
- `WORKED_EXAMPLES/J04_missing_override.md`;
- any other journey, failure case, implementation implication, or metric that assumes the old single enum.

## Required correction 3 — remove ambiguity from the architecture scoring matrix

`DECISION_MATRIX.md` uses a 1–5 scale and an additive `Overall` score, but the direction and rubric are not sufficiently defined for every criterion.

In particular:

```text
Implementation complexity
```

is ambiguous because a larger number could mean "more complex" or "better/easier to implement."

Repair this by either:

### Option A — explicit heuristic rubric

Define:

- what 1 and 5 mean for every criterion;
- whether higher is always better;
- how implementation complexity is normalized;
- whether criteria are equally weighted;
- why summing the scores is appropriate;
- that the score is a research heuristic, not measured usability performance.

or:

### Option B — qualitative decision matrix

Remove the pseudo-precise total and compare the architectures with explicit strengths, risks, implementation burden, and evidence basis.

Do not imply that `35` is an empirically measured superiority result. The package correctly states that practicing-estimator usability testing has not yet been performed; preserve that limitation.

## Required validation

Before resealing:

1. Search for all uses of `corrected`, `overridden`, `confirmed`, and `review_disposition` and reconcile them with the repaired model.
2. Validate the JSON representation.
3. Re-run both count/recount scripts.
4. Re-run manual source/pattern spot checks.
5. Regenerate `SHA256SUMS.txt` only after final content stabilizes.
6. Verify all hashes from a clean extract.

## Return package

Return exactly one ZIP:

```text
RESEARCH_5_R4_UX_001_R2.zip
```

Status inside the package:

```text
READY_FOR_RESEARCH_B_TL_REVIEW
```

## Scope discipline

No production implementation.  
No Git writes.  
No new PM policy decisions.  
No claim that the proposed UX has proven human-performance gains without usability testing.

This is **Backjob 1** for `R4-UX-001`.
