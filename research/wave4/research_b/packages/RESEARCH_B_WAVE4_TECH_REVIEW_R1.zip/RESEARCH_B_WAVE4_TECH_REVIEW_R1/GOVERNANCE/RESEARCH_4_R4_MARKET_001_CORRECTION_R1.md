# Research 4 — R4-MARKET-001 Focused Correction R1

## Role and routing

Worker: **Research 4**

Task:

```text
R4-MARKET-001
Construction Takeoff / BOQ Competitive Landscape
```

Routing remains:

```text
Research 4
→ Research B TL
→ Research B QA
→ PM
```

This is a **focused evidence-classification correction only**. Do not restart the market study, broaden the competitor set merely to add volume, or perform production/Git changes.

## TL review result

Status:

```text
TL_RETURNED_FOR_FOCUSED_CORRECTION_R1
```

The R1 package is structurally strong and materially meets the research objective. Checksums, package counts, source references, minimum product/deep-profile counts, opportunity count, pricing provenance, contradiction handling, and benchmark-access limitations were independently checked by Research B TL.

The strategic conclusion is not being rejected.

## Required correction 1 — tighten `BENCHMARKED_RESULT` semantics

The seven `BENCHMARKED_RESULT` cells for the academic 2D QTO prototype currently include descriptive properties such as:

- PDF-study scope;
- computer-vision boundary detection;
- narrow element scope;
- research-output/provenance posture;
- academic reproducibility/audit posture;
- geographic/research classification.

These are not all benchmark **results**.

Reserve:

```text
BENCHMARKED_RESULT
```

for a capability/result that was actually measured under a defined benchmark or experimental evaluation.

For descriptive properties directly established by the paper, use the most defensible non-benchmark class allowed by the governing assignment, normally:

```text
DOCUMENTED_FEATURE
```

Use:

```text
UNVERIFIED
```

where the paper does not directly support the capability statement.

The automatic irregular-area result may remain `BENCHMARKED_RESULT` where the claim explicitly corresponds to the measured experiment and retains its narrow scope.

Do not generalize the paper's reported 94.1% automatic area accuracy or approximately 99% time reduction beyond the tested irregular-area task.

## Required correction 2 — make benchmark counts non-inflating

After reclassification:

- update `EVIDENCE/capability_claims.csv`;
- update `SOURCE_NOTES/academic_2d_qto_prototype.md`;
- update `SELF_REVIEW.md`;
- update `DECISION_MATRIX.md` counts where affected;
- update any validator/recompute outputs or summaries that report classification counts;
- search the full package for stale `BENCHMARKED_RESULT=7` or equivalent statements.

A reader must not be able to interpret "7 benchmarked cells" as seven independently measured benchmark outcomes.

## Required correction 3 — preserve the existing strategic conclusion unless evidence changes

The following conclusion is accepted in substance and should remain qualified rather than broadened:

> Automatic takeoff and visual traceability are already present in the market; the more defensible differentiation target is evidence-complete, fail-closed, reproducible drawing-to-BOQ reasoning.

Do not convert absence of public evidence into proof that a competitor lacks a capability.

## Required validation

Before resealing:

1. Re-run the structural validator.
2. Re-run the independent recomputation.
3. Verify every non-`UNVERIFIED` capability row still has valid source support.
4. Manually inspect every remaining `BENCHMARKED_RESULT` row and record why it is a measured result rather than a descriptive feature.
5. Regenerate `SHA256SUMS.txt` only after the package is final.
6. Verify all hashes from a clean extract.

## Return package

Return exactly one ZIP:

```text
RESEARCH_4_R4_MARKET_001_R2.zip
```

Status inside the package:

```text
READY_FOR_RESEARCH_B_TL_REVIEW
```

## Scope discipline

No new production code.  
No Git writes.  
No procurement authorization.  
No simulated commercial benchmark results.

This is **Backjob 1** for `R4-MARKET-001`.
