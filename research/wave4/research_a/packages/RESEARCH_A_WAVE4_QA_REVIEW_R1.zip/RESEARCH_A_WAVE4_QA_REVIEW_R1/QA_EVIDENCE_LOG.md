# Research A Wave 4 QA Evidence Log

## Independent reruns

- Research 1 `SUPPORT/validate_corpus_research.py`: PASS, 256/256 checks.
- Research 2 package contract validator: PASS.
- Research 2 contract negative test: PASS.
- Research 2 overall validator: PASS, 3 successful object-level real-DWG walkthrough records.
- Research 3 `support/validate_package.py`: PASS.
- Research 3 `support/score_benchmark.py`: PASS.
- Research 3 `support/independent_example_recompute.py`: PASS, FAA count 3.

## Independent recomputations

- TL seal: every declared SHA-256 matched and every non-manifest file was covered.
- Each worker seal: every declared SHA-256 matched and every non-manifest file was covered.
- R1 semantic distinctness: 52/52 independently recomputed.
- R2 walkthrough entity-type and layer-use sums: exact 11 / 181 / 742 reconciliation.
- R2 source-register path/blob/size linkage: exact for WT-01/02/03.
- R3 stored semantic hashes: 87/87 independently recomputed and matched.
- R3 family leakage: 80 families, zero cross-split family leakage.
- R3 task coverage: 1 through 18 complete.

## Independent repository provenance check

Pinned commit:
`97f16aa3fd7b6d8e7cd364b6edc2ac303a5f54e6`

Exact path lookups returned the claimed blobs for all three accepted R2 walkthroughs. Binary headers also matched the recorded AC1032 / AC1032 / AC1018 families.

## Independence boundary

QA did not simply accept TL PASS labels. Structural validators were rerun, key counts/hashes were recomputed separately, R2 raw/dataset/source-register consistency was recalculated, R3 semantic hashes and split lineage were recalculated, and R2 repository provenance was checked independently.

The QA runtime did not locally execute the worker's native DWG reader over newly downloaded binaries, so that remaining dependency is explicitly carried as a non-blocking note.
