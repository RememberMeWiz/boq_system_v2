# Research A Wave 4 QA Review R1

## Subject

- Source package: `RESEARCH_A_WAVE4_TECH_REVIEW_R1.zip`
- Source package SHA-256: `f01d1d11afe42846387daac564ad48a7e55565d75e26292e76ce2993149544d8`
- Subject TL state: `READY_FOR_RESEARCH_A_QA`
- Governing QA role: Research A QA
- Route: Research 1 / Research 2 / Research 3 → Research A TL → Research A QA → PM

## Final QA verdict

```text
QA_PASS_WITH_NOTES
READY_FOR_PM
```

No blocking correction is required before PM review.

## Independent QA conclusion

Research A demonstrated the claims it actually framed as Wave 4 research claims. The sealed TL handoff and all three embedded worker packages are internally intact, the supplied validators rerun successfully, the material counts and semantic-distinctness claims independently reconcile, Research 2's three accepted DWG objects resolve to the claimed pinned Git blobs, and the packages preserve rather than erase important limits.

The QA pass does **not** promote the Research 1 discovery inventory to gold truth, does not convert Research 2's three native reads into a universal DWG-compatibility claim, and does not treat Research 3's synthetic benchmark or proposed thresholds as empirical production accuracy evidence.

## Package and seal checks

- TL package SHA manifest: 24/24 entries verified.
- TL package checksum coverage: every regular file except `SHA256SUMS.txt` itself is covered.
- Embedded worker ZIP hashes: verified against the TL package seal.
- Research 1 internal checksum coverage: 74/74 declared files verified; no unsealed payload file.
- Research 2 internal checksum coverage: 83/83 declared files verified; no unsealed payload file.
- Research 3 internal checksum coverage: 43/43 declared files verified; no unsealed payload file.
- No path or package-integrity blocker found.

## Research 1 — R4-CORPUS-001

QA disposition: `QA_PASS_WITH_NOTES`

Independent checks:
- Fresh worker validator: `256/256` PASS.
- Corpus records: 52.
- Unique candidate IDs: 52.
- Recomputed presentation-insensitive semantic hashes: 52 distinct of 52.
- Truth state: 52/52 remain `REFERENCE_BOQ`.
- Rights classifications remain explicit for all 52 candidates.
- Source register: 53 primary/official records; the four rows without candidate IDs are legal/rights governance references, not missing candidate links.
- The package defines `REFERENCE_BOQ`, `CANDIDATE_TRUTH`, `ADJUDICATED_GOLD_TRUTH`, and `UNRESOLVED` distinctly.

QA note:
The 52 retained pairs are source-discovery/attachment-list evidence, not byte-ingested, revision-reconciled, rights-cleared, adjudicated gold cases. This boundary is explicit and correctly preserved. Downstream teams must not relabel the current inventory as benchmark gold or assume redistribution permission.

## Research 2 — R4-DWG-001

QA disposition: `QA_PASS_WITH_NOTES`

Independent checks:
- Package contract validator: PASS.
- Contract negative control: PASS.
- Overall validator: PASS.
- Source register: 38 candidates, 38 unique repository paths, 38 unique Git blob SHAs.
- Three native walkthrough records reconcile exactly across raw walkthrough JSON and `DATASETS/source_walkthroughs.json`.
- WT-01: 11 modelspace entities; entity-type sum = 11; layer-usage sum = 11; INSUNITS = 1.
- WT-02: 181 modelspace entities; entity-type sum = 181; layer-usage sum = 181; INSUNITS = 4.
- WT-03: 742 modelspace entities; entity-type sum = 742; layer-usage sum = 742; INSUNITS = 1.
- Candidate path, Git blob SHA, registered size, and walkthrough size reconcile for all three accepted walkthroughs.
- Independent repository lookup at pinned revision `97f16aa3fd7b6d8e7cd364b6edc2ac303a5f54e6` returned the exact claimed Git blob SHAs:
  - WT-01: `a401275ebc1147a2cbc68b44c5947f8da53a3616`
  - WT-02: `489fa5a21870a4cef4d76e29290e415aebd9f17f`
  - WT-03: `93978bb486e4586eda44275d178c70e62ca4cf48`
- The fetched binary headers are consistent with the recorded DWG families: WT-01/02 begin with `AC1032`; WT-03 begins with `AC1018`.
- CAD-023's `ezdwg 0.11.0` decompressor failure is preserved as a failure, not converted into fabricated entity observations.

QA notes:
1. QA independently verified pinned blob identity and header family, and independently reconciled all sealed walkthrough counts, but did not independently execute `ezdwg` over locally re-downloaded copies of the three DWGs in this QA runtime. The object inventories therefore retain an evidence dependency on the worker's native execution record, strengthened by TL review and QA provenance checks.
2. The current validator automatically proves package shape and minimum successful-walkthrough count, but it does not itself recompute every walkthrough JSON-to-dataset reconciliation that QA performed manually. Future revisions should promote those reconciliation checks into the validator.
3. Three successful files plus one preserved AC1021 reader failure demonstrate bounded native-read evidence only. They do not establish universal DWG version support, parser accuracy, or quantity correctness.

## Research 3 — R4-PARSERBENCH-001

QA disposition: `QA_PASS_WITH_NOTES`

Independent checks:
- Fresh package validator: PASS.
- Cases: 87.
- Recomputed semantic hashes: 87/87 match the stored hashes and remain 87 distinct.
- Families: 80 across 87 cases.
- Seven families intentionally contain more than one case.
- No family crosses development / validation / sealed-holdout boundaries.
- Split distribution: development 52, validation 11, sealed holdout 24.
- Task coverage: all task IDs 1 through 18 represented.
- Adversarial cases: 56.
- Conflict/missing cases: 26.
- Source-localization cases: 30.
- Cross-sheet cases: 20.
- Source register: 30 unique sources, all with non-empty provenance/limitation fields.
- Fresh reference scorer and separately implemented worked-example oracle agree on exactly three false-automatic-acceptance events:
  - `WX-02 / T1`
  - `WX-03 / T1`
  - `WX-07 / T1`

QA notes:
1. The 87-case benchmark is a synthetic benchmark design. It is not real-drawing parser-accuracy evidence.
2. Production acceptance/calibration thresholds remain research proposals pending a licensed/controlled real-drawing pilot and adjudicated truth.
3. The current package validator checks stored semantic-hash uniqueness but does not itself recompute each semantic hash. QA independently recomputed all 87 and found no mismatch. Future validator hardening should make this automatic.
4. Human-review burden is structurally modeled but not yet empirically timed.

## Cross-worker QA synthesis

The three worker outputs form a coherent research ladder without collapsing evidence levels:

1. Research 1 establishes rights-aware source discovery, corpus identity, truth states, and adjudication boundaries.
2. Research 2 establishes native-CAD evidence contracts and bounded real-DWG object-level observations with preserved failure evidence.
3. Research 3 establishes a benchmark/scoring design for parser correctness, source support, conflicts, cross-sheet reasoning, abstention, and unsafe automatic acceptance.

No package provides end-to-end production parser accuracy or solver correctness, and none is accepted as doing so.

## Defect register

### Blocking / High

None.

### Medium

None requiring return.

### Notes / hardening opportunities

- R2: add automatic walkthrough JSON ↔ dataset/source-register reconciliation to the validator.
- R2: future QA should cross-read native DWGs with a second independent reader/toolchain where licensing and runtime permit.
- R3: recompute semantic hashes inside the package validator instead of trusting stored hashes for the uniqueness check.
- R1: retain the current rights and truth-state gates through any later byte-ingestion pilot.

## Required corrections

```text
NONE BEFORE PM REVIEW
```

## PM routing state

```text
QA_PASS_WITH_NOTES
READY_FOR_PM
```

PM should treat the notes above as implementation/research constraints, not as evidence that the Wave 4 Research A handoff failed.
