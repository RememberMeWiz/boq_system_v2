# Research A Wave 4 Conflict Register

## Resolved conflicts

### R2 stale PASS/BLOCKED contradiction

Earlier Research 2 correction packages simultaneously contained fresh PASS evidence and stale blocked-state narrative. Correction R4 resolves current-state artifacts. Historical blocked entries remain only where clearly part of chronology or schema vocabulary.

Status: `RESOLVED`.

### WT-03 provenance mismatch

Earlier correction material contained inconsistent WT-03 path/hash/layer summaries. Correction R4 reconciles WT-03 to:

- path: `backend/reference_data/cad_drawings/Water Tank Design/Copy of 01Overhead Water Tank  Detail.dwg`;
- Git blob: `93978bb486e4586eda44275d178c70e62ca4cf48`;
- worker-recorded byte SHA-256: `1b4f758b2b585ac462038897617b2085c7bad9b11339012e7ca7566f4ba194ac`;
- entity total: 742;
- layer-usage total: 742 across 54 raw layer-handle keys.

Status: `RESOLVED`.

## Preserved non-blocking tensions / limitations

### Native reader compatibility

CAD-023 (AC1021) failed under `ezdwg 0.11.0` while the accepted WT-01/02/03 files parsed successfully. This is not reconciled into a claim of broad DWG compatibility.

Status: `OPEN_LIMITATION_NONBLOCKING`.

### Corpus discoverability versus redistribution rights

Research 1 distinguishes public discoverability from rights to redistribute or treat a source as benchmark gold.

Status: `OPEN_LIMITATION_NONBLOCKING`.

### Benchmark thresholds versus empirical production calibration

Research 3 proposes scoring/calibration/abstention controls but does not claim that final production thresholds are empirically established.

Status: `OPEN_LIMITATION_NONBLOCKING`.

No unresolved cross-worker contradiction blocks Research A QA review.
