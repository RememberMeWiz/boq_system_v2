# Research A Wave 4 Final Technical Review

## TL disposition

`READY_FOR_RESEARCH_A_QA`

All three Wave 4 Research A assignments are accepted at TL.

## Research 1 — R4-CORPUS-001

Disposition: `ACCEPTED_AT_TL`

Final regression findings:
- sealed ZIP integrity PASS;
- all internal SHA-256 entries PASS;
- corpus validator: `256/256 checks passed`;
- 52 candidate rows and 52 unique IDs remain the accepted corpus inventory;
- truth-state boundary remains preserved: corpus entries are `REFERENCE_BOQ`, not adjudicated gold truth;
- rights/discoverability and redistribution rights remain separate concerns;
- no semantic-count-inflation blocker was identified in the accepted package.

Accepted limitation: the corpus program is a benchmark/corpus framework and reference inventory, not a claim that all registered sources are byte-ingested, rights-cleared, or adjudicated gold truth.

## Research 2 — R4-DWG-001

Disposition: `ACCEPTED_AT_TL`

Correction R4 closes the remaining blocker and all reconciliation controls.

Fresh TL validation:
- outer ZIP integrity PASS;
- all internal SHA-256 entries PASS;
- package contract validator PASS;
- contract negative control PASS;
- overall validator PASS;
- `successful_object_level_real_dwg_walkthroughs = 3`;
- WT-01/02/03 raw entity-type totals equal modelspace entity totals;
- WT-01/02/03 raw layer-usage totals equal modelspace entity totals;
- datasets and worked examples reconcile with raw machine JSON;
- current worker state is `READY_FOR_RESEARCH_A_TL`, with QA promotion correctly left to TL;
- production changes = 0 and Git writes = 0.

Independent pinned Git-blob verification:
- WT-01 / CAD-020: `a401275ebc1147a2cbc68b44c5947f8da53a3616`;
- WT-02 / CAD-021: `489fa5a21870a4cef4d76e29290e415aebd9f17f`;
- WT-03 / CAD-037: `93978bb486e4586eda44275d178c70e62ca4cf48`.

Walkthrough totals:
- WT-01: 11 modelspace entities, INSUNITS=1 inches;
- WT-02: 181 modelspace entities, INSUNITS=4 millimeters;
- WT-03: 742 modelspace entities, INSUNITS=1 inches.

Preserved limitation: `ezdwg 0.11.0` failed on the originally preferred CAD-023 AC1021 file with a decompression-offset error. The package preserves that failure without fabricated observations and substitutes the equally pinned CAD-037 as WT-03. This proves three successful native walkthroughs exist; it does not establish universal DWG-reader compatibility or parser accuracy across all repository drawings.

Preserved evidence boundary: native object presence and annotations are evidence candidates. They do not by themselves prove concrete volume, reinforcement weight, occurrence count, or commercially valid quantity. Quantity derivation still requires semantic decoding, geometry validation, unit normalization, cross-sheet reconciliation, and engineering verification.

## Research 3 — R4-PARSERBENCH-001

Disposition: `ACCEPTED_AT_TL`

Final regression findings:
- sealed ZIP integrity PASS;
- all internal SHA-256 entries PASS;
- package validator PASS;
- 87 benchmark cases;
- 56 adversarial cases;
- 26 conflict/missing cases;
- 30 source-localization cases;
- 20 cross-sheet cases;
- 7 worked examples;
- 30 sources;
- 87 semantically distinct cases;
- task coverage 1 through 18 complete;
- independent worked-example recompute still returns exactly 3 false-automatic-acceptance events: WX-02/T1, WX-03/T1, WX-07/T1.

Accepted limitation: calibration and acceptance thresholds remain benchmark proposals until validated on a licensed real-drawing pilot/corpus. Human review burden is structurally modeled but not yet empirically timed across production users.

## Cross-worker synthesis

The three assignments form a coherent evidence ladder:

1. Research 1 defines a provenance-aware corpus program and explicit truth states.
2. Research 2 defines native CAD evidence boundaries and proves object-level extraction on three pinned repository DWGs while preserving a real reader failure.
3. Research 3 defines the parser benchmark/scoring framework needed to measure extraction, localization, conflicts, cross-sheet reasoning, calibration, abstention, and unsafe automatic acceptance.

No worker submission is treated as proof of end-to-end parser accuracy or production solver correctness. Those claims remain outside Wave 4 Research A acceptance.

## QA handoff

Research A QA should independently verify the embedded worker ZIP hashes, rerun the supplied validators, inspect the Research 2 raw native walkthrough JSONs and CAD-023 failure evidence, and challenge the preserved limits listed above.

TL status: `READY_FOR_RESEARCH_A_QA`.
