# Research A Wave 4 Backjob Log

## Research 1

No final blocking backjob remained. Submission frozen as `ACCEPTED_AT_TL` after the initial technical review.

## Research 3

No final blocking backjob remained. Submission frozen as `ACCEPTED_AT_TL` after the initial technical review.

## Research 2 — R4-DWG-001

### Initial TL blockers

- `A-R2-BJ-001`: mandatory Wave 4 package shape / exact package identity.
- `A-R2-BJ-002`: at least three actual object-level native real-DWG walkthroughs.
- `A-R2-BJ-003`: validator must enforce the package contract and demonstrate a failing negative control.

### Correction R1

Result:
- BJ-001 PASS.
- BJ-002 FAIL/BLOCKED in worker sandbox because no successful native object-level reads existed.
- BJ-003 PASS.

TL action: kept only BJ-002 open.

### Correction R2

Desktop native execution produced three successful walkthroughs and the overall validator passed, but the sealed package contained stale blocker artifacts and provenance/summary contradictions. TL did not promote contradictory evidence to QA.

### Correction R3

Evidence reconciliation fixed the main provenance contradictions. This was the third backjob cycle on the assignment, so TL issued the required PM loop-review notice. Remaining defects were narrowed to current-text cleanup and explicit mapping/custody reconciliation.

### Correction R4

Final surgical reconciliation PASS:
- current README state corrected;
- WT-03 quantity-completeness overclaim removed/downgraded;
- R3-BJ-001 through R3-BJ-005 explicitly mapped;
- CAD-023 failure and CAD-037 substitution explicitly preserved in process/custody records;
- all validators PASS;
- all checksums PASS;
- current-state evidence is self-consistent.

Final Research 2 disposition: `ACCEPTED_AT_TL`.
