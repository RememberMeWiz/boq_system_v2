# Validator Independence Review  -  Independent Research Wave 3 QA R1

## Classification rule

Worker-authored package validators are classified as **self-consistency/reproducibility evidence**, not as independent proof of research correctness.

Worker-authored “independent oracle” scripts are useful separate implementation paths, but they remain worker evidence. QA therefore reran them for reproducibility and then independently recomputed critical numerical/logical results without importing the worker oracle code.

## Clean-extraction reruns

QA made separate working copies, hashed the complete file tree before execution, ran the documented entry points with bytecode writing suppressed, then hashed the entire tree again.

| Package | QA rerun | Result | Tree mutation |
|---|---|---|---|
| R3-COST-001 | validator + worked-example oracle | validator 67/67; oracle 12/12 | none |
| R3-ONTOLOGY-001 | semantic oracle + final validator | oracle 16/16 worked examples and 84/84 conversion decisions; validator PASS | none |
| R3-RCBEAM-001 | pre-integrity, validator, normative oracle, cutting oracle, post-integrity | all PASS; 23 exact passing procurement cases reproduced by worker oracle | none |
| R3-BOUNDARY-001 | validator + transition oracle | PASS; 12/12 oracle trace matches | none |
| R3-AUDIT-001 | validator + deterministic trace oracle | PASS; 12/12 trace recalculations | none |
| R3-STANDARDS-001-CORRECTION-R3 | package validator | PASS; SHA clean; 73 sources | none |

Complete pre/post file counts were respectively 46, 57, 79, 57, 85 and 43 files, with zero changed, added or removed files after the QA reruns.

## R6 duplicate-locator warning

The R6 validator reported two repeated official-locator URLs. QA inspected them:

- the GPPB resolutions index is shared by two different GPPB resolutions;
- the RICS NRM family landing page is shared by NRM 1, NRM 2 and NRM 3.

These are distinct underlying documents sharing a publisher family/index locator. They are not duplicate source identities.

## Independent QA work beyond validators

QA separately reproduced:

- COST worked examples: 12/12;
- ONTOLOGY dimensional worked examples: 16/16;
- RCBEAM fabrication transformations: 24/24;
- RCBEAM normative beam cases: 2/2;
- RCBEAM procurement cases: 25/25, including two correctly blocked overlength cases, using a reviewer-written exact demand-state DP;
- BOUNDARY state transitions: 12/12 using reviewer-written invariant logic;
- AUDIT deterministic calculation traces: 12/12.

The detailed arithmetic/state outputs are in `INDEPENDENT_RECALCULATIONS.json`.

## Oracle conclusion

No Wave 3 package is passed merely because its own validator is green.

The supplied validators demonstrate package integrity and internal consistency. The QA verdict is based additionally on independent hard-gate recounts, semantic sampling, external source verification and reviewer-written recalculation paths.
