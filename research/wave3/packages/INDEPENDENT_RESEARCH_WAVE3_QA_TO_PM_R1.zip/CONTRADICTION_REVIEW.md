# Contradiction Review  -  Independent Research Wave 3 QA R1

## Blocking contradictions

None found.

The major cross-research tensions are correctly exposed as owner decisions rather than silently resolved inside worker recommendations.

## Reviewed boundaries

### Measurement regime versus source authority

RCBEAM uses professional measurement references as coherent candidates, while STANDARDS correctly distinguishes credibility from project-governing applicability. QA finds no basis to treat any professional measurement regime as universal project policy.

### Structural/detailing rules versus measurement/procurement logic

RCBEAM separates engineering/design/detailing evidence from measurement, fabrication and procurement. Metadata-only access to protected standards does not authorize inaccessible clause-level rules.

### Parser confidence versus solver eligibility

BOUNDARY preserves the governing Wave 3 baseline that unreviewed solver-critical facts require review. Confidence is not treated as an automatic release permission.

### Rate eligibility versus commercial precedence

COST and STANDARDS converge on claim-specific eligibility/provenance while deliberately leaving universal source/rate precedence to PM/commercial policy.

### Historical preservation versus protected-source licensing

AUDIT's immutable-evidence direction and STANDARDS' protected-source constraints are compatible only if the architecture supports lawful retained artifacts/references instead of assuming every protected source can be copied into open evidence.

### Mutable publisher metadata

Research 6's correction history demonstrates that “current” status is time-bounded. QA independently confirmed the corrected current ISO/ASTM states on 2026-08-14, but this does not make them timeless. `status_checked_at`/knowledge-time provenance remains necessary.

## QA-specific discrepancies and notes

1. **RCBEAM multi-diameter count.** TL reports 18 distinct rows. QA counts 17 genuinely multi-diameter cases because `MD-017` contains only one demand diameter. The minimum is 15, so the gate remains closed.
2. **Research 2 repository-governance note.** Its process log discloses two attempted GitHub `create_tree` calls during connector discovery. Both were denied HTTP 403 and no repository state changed. This is a process-hygiene note, not a provenance break, but future research should remain read-only absent explicit PM write authorization.
3. **R6 current-standard metadata.** The corrected ASTM C94/C94M-26c designation is supported as a dated first-party observation, not as an eternal edition claim.

## Adoption boundary

Research QA success means the Wave 3 packages sufficiently support their own research claims.

It does **not** adopt:

- NRM/measurement policy;
- structural design/detailing choices;
- splice/coupler or procurement policy;
- automatic parser acceptance;
- rate precedence, VAT/FX/waste or override policy;
- source-authority scoring policy;
- storage architecture;
- standards editions for a specific project;
- any production code change, merge or Repository Steward action.

## Result

`NO_BLOCKING_CONTRADICTION`

Primary QA verdict: `QA_PASS_WITH_NOTES`.
