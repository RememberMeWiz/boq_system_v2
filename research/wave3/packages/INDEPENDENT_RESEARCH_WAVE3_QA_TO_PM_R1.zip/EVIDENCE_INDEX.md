# Evidence Index  -  Independent Research Wave 3 QA R1

## Governing input

- `INDEPENDENT_RESEARCH_WAVE3_TECH_REVIEW_R1.zip`
- QA-computed input SHA-256: `4b231c5f3f0d0ab4e7e460663a5e85eee5589773b46f0669f8f0947e7477a263`
- Research QA Reviewer Charter from the project conversation
- TL preserved directive: `references/RESEARCH_WAVE3_TL_DIRECTIVE_R1.md`

## TL synthesis reviewed

- `TECH_REVIEW.md`
- `QA_REVIEW_INSTRUCTIONS.md`
- `PROCESS_DEPTH_REVIEW.md`
- `CROSS_RESEARCH_CONTRADICTIONS.md`
- `CROSS_RESEARCH_DECISION_REGISTER.md`
- `DEFERRED_POLICY_DECISIONS.md`
- `SOURCE_AUTHORITY_SUMMARY.md`
- `evidence/independent_checks/TL_SEMANTIC_RECOUNT.json`
- `evidence/independent_checks/TL_INDEPENDENT_RECALCULATIONS.json`
- `evidence/validation_runs/TL_CLEAN_EXTRACTION_VALIDATION.json`

## Final worker packages reviewed

- `RESEARCH_1_R3_COST_001.zip`
- `RESEARCH_2_R3_ONTOLOGY_001.zip`
- `RESEARCH_3_R3_RCBEAM_001.zip`
- `RESEARCH_4_R3_BOUNDARY_001.zip`
- `RESEARCH_5_R3_AUDIT_001.zip`
- `RESEARCH_6_R3_STANDARDS_001_CORRECTION_R3.zip`

## QA-generated evidence

- `HARD_GATE_RECOUNT.json`  -  independent count/depth gate closure, including supplemental numeric gates encoded in package validators/tasks.
- `SOURCE_VERIFICATION.json`  -  25 externally checked sources, all classified primary/official/technical for the sampled purpose.
- `SEMANTIC_SAMPLING.json`  -  charter-sized samples of every hard-gate corpus plus source-register and worked-example sampling.
- `INDEPENDENT_RECALCULATIONS.json`  -  reviewer-written arithmetic/state/optimization recomputation.
- `VALIDATOR_INDEPENDENCE.md`  -  clean rerun and oracle-classification record.
- `CONTRADICTION_REVIEW.md`  -  cross-worker and QA-specific contradiction/policy-boundary review.
- `CHAIN_OF_CUSTODY.json`  -  package/manifests/hashes and clean-run mutation record.

## Correction-sensitive external evidence focus

Research 6's three-round correction chain received special review. Independent live publisher checks supported:

- current ISO 12006-2:2015 status;
- cancellation/deletion of the Edition 3 DIS project;
- ASTM C94/C94M-26C as the current Active version on the ASTM C94 family page at QA check time.

Those findings remain time-bounded and must be refreshed when a future adoption/use decision depends on “current”.
