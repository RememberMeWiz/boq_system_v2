# Cross-Research Contradictions

Wave 3 has more convergence than hard contradiction. The important conflicts are mostly **policy boundaries that research correctly refused to resolve**.

## XR-01 — Measurement regime versus source authority

Research 3 uses RICS NRM2 as a coherent candidate RC-beam measurement regime.

Research 6 shows that professional measurement references are not automatically governing for a project merely because they are credible.

**Impact:** RC beam formula/measurement implementation cannot hard-code NRM2 as universal project policy.

**Owner:** PM + quantity-surveying/domain authority.

**State:** `POLICY_DECISION_REQUIRED`.

## XR-02 — Structural/detailing evidence versus measurement/procurement

Research 3 identifies ACI/PNS/BBS/detailing references, but Research 6's source model distinguishes source authority, applicability, incorporation and claim-access level.

**Impact:** lap, development length, hooks, splice zones, couplers and BBS regime cannot be invented by procurement logic or adopted from metadata alone.

**Owner:** Engineering/design authority + PM.

**State:** `DOMAIN_REVIEW_REQUIRED`.

## XR-03 — Strict parser review versus future automatic acceptance

Research 4 preserves the Wave 3 baseline:

`UNREVIEWED + solver-critical → REVIEW_REQUIRED`.

It also surfaces future whitelist/quorum alternatives.

**Impact:** Parser/Integration may implement the state model now, but automatic acceptance remains unadopted until calibrated evidence and PM policy exist.

**Owner:** PM + Parser/Integration QA.

**State:** `POLICY_DECISION_REQUIRED`.

## XR-04 — Rate precedence and public-reference scope

Research 1 treats DPWH/public references as scope-specific rather than universal private-project price authority.

Research 6 reaches the same claim-specific-authority conclusion.

**Impact:** a technical rate resolver can implement eligibility and provenance, but cannot select a universal commercial hierarchy.

**Owner:** PM / Commercial.

**State:** `POLICY_DECISION_REQUIRED`.

## XR-05 — Waste/allowance ownership

Research 1 argues physical wastage belongs to resource/quantity transformation unless the rate explicitly includes it.

Research 2 says allowance/waste is a typed transformation.

Research 3 rejects mixing concrete waste into normative measured volume.

**Impact:** architecture is convergent, but trade-specific factors and which stages receive them remain policy/methodology decisions.

**Owner:** Solver + PM / QS domain.

**State:** `POLICY_DECISION_REQUIRED`.

## XR-06 — Procurement optimizer objective/offcut policy

Research 3 shows multiple valid objectives and treats offcut reuse threshold as company/commercial policy.

Research 2 provides semantic stage support but cannot choose the objective.

**Impact:** optimizer architecture can be tested without adopting a single procurement objective.

**Owner:** Commercial / company policy owner.

**State:** `POLICY_DECISION_REQUIRED`.

## XR-07 — Historical preservation versus protected-source licensing

Research 5 favors retained immutable evidence for reproduction.

Research 6 warns that protected standards cannot simply be copied into open project evidence.

**Impact:** audit architecture must support lawful snapshots/references and protected/licensed vault references instead of assuming every source can be embedded.

**Owner:** Architecture + Legal/Compliance.

**State:** `POLICY_DECISION_REQUIRED`.

## XR-08 — Mutable publisher metadata

Research 6's ASTM C94 correction chain demonstrates that a publisher's “current” metadata may change faster than search/index snapshots.

Research 5 and Research 1 already require historical knowledge-time/source-state preservation.

**Impact:** `status_checked_at` and estimate freeze state are necessary; “latest” must not be timeless cached truth.

**Owner:** Integration + Audit.

**State:** `ADOPTION_CANDIDATE` for temporal provenance; exact edition remains fresh-lookup/project-policy dependent.

## XR-09 — Quantity-stage refinement versus Wave 2 pseudo-dimensions

Research 2 refines prior pseudo-dimension treatment for count/currency without discarding semantic guards.

**Impact:** no blocking conflict, but future schema should distinguish physical dimension from semantic algebra/kind.

**Owner:** Integration architecture.

**State:** `IMPLEMENTATION_CANDIDATE`.

## Overall

No cross-research contradiction blocks Research QA.

The unresolved items are deliberately exposed as engineering, commercial, legal, workflow or PM policy decisions rather than being hidden inside code candidates.
