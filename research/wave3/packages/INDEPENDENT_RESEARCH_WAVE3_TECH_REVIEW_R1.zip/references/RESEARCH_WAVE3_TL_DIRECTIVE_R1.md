# PM DIRECTIVE — RESEARCH WAVE 3

**Project:** `boq_system_v2`  
**Directive:** `RESEARCH_WAVE3_TL_DIRECTIVE_R1`  
**Date:** 2026-08-14 (Philippines time)  
**From:** Project Manager  
**To:** Research Team Leader  
**Status:** `PM_RESEARCH_AUTHORIZED`

---

# 1. Purpose

Start Research Wave 3 as an implementation-facing research wave that converts the accepted Wave 2 evidence into decision-ready references for Solver, Parser, Integration, and later PM adoption.

Wave 3 must increase **depth, evidence quality, implementability, and first-pass completeness**.

The goal is not to produce larger documents for their own sake. The goal is to reduce downstream ambiguity and reduce the number of TL/QA backjobs by making each worker package substantially harder to complete superficially.

Wave 3 remains research only.

```text
Production code changes: NOT AUTHORIZED
Methodology adoption: NOT AUTOMATIC
Commercial policy adoption: NOT AUTOMATIC
Structural/engineering design decisions: NOT AUTOMATIC
Repository Steward action: SEPARATE PM DECISION
```

---

# 2. Why Wave 3 is being structured differently

The Product Owner reports that the previous research assignments were intentionally designed to require at least roughly five hours of substantive work per worker, yet the longest observed worker run was approximately 68 minutes.

Elapsed time alone is not a quality criterion, and workers must never idle merely to satisfy a clock target. However, completion that is radically faster than the designed research envelope is a warning signal when the assignment is supposed to require:

- primary-source research;
- adversarial source comparison;
- numerical or logical verification;
- independent oracles;
- dataset/case construction;
- source provenance;
- contradiction analysis;
- policy classification;
- implementation-facing synthesis;
- reproducibility evidence.

Therefore Wave 3 uses a **substantive-effort floor by task design**, not an artificial waiting requirement.

Each assignment must contain enough independent research, verification, comparison, and evidence production that a genuine high-quality completion would normally represent at least about **five hours of focused research work**.

A worker who completes much faster may still pass, but the Research TL must treat unusually fast completion as an **adversarial-review trigger**, not as proof of efficiency.

No worker may satisfy this requirement by waiting, padding prose, duplicating sources, generating cosmetic cases, or inflating artifact counts.

---

# 3. Wave 3 operating principle

Every worker must answer all four questions:

```text
1. What does the evidence say?
2. Which parts are facts, standards, conventions, policies, assumptions, or software decisions?
3. What contradictions, boundary conditions, and failure cases exist?
4. What exact decision options should the project consider next?
```

Research must remain distinguishable from adoption.

A recommendation does not become project policy because a research worker recommends it.

---

# 4. Research Wave 3 workers

Wave 3 authorizes six parallel research workstreams.

Existing workers:

```text
Research 1
Research 2
Research 3
Research 4
```

New workers:

```text
Research 5
Research 6
```

The Research TL remains the single technical synthesis owner.

Research QA remains the independent gate after TL acceptance.

---

# 5. Worker assignments

## Research 1 — R3-COST-001

### Title

**Rate Engine, Commercial Provenance, and Price-Normalization Decision Pack**

### Objective

Produce an adoption-ready evidence pack defining candidate behaviors for a trustworthy BOQ rate engine without unilaterally selecting commercial policy.

### Required research areas

Research and compare:

- source hierarchy for construction rates;
- Philippine government/public rate references where applicable;
- supplier/vendor quotations;
- historical estimate rates;
- contract/project-specific rates;
- regional normalization;
- effective-date handling;
- escalation and de-escalation;
- inflation/index-based normalization;
- labor/material/equipment component separation;
- taxes and VAT treatment;
- delivery/freight;
- wastage treatment;
- currency handling;
- rate overrides;
- override expiry;
- stale-rate detection;
- conflicting-rate resolution;
- source confidence versus source authority;
- rate versioning;
- reproducibility of an old estimate;
- missing-price behavior;
- composite versus elemental rates.

### Required outputs

At minimum:

1. source-authority matrix;
2. rate provenance schema proposal;
3. normalization decision matrix;
4. escalation/de-escalation model comparison;
5. conflicting-source scenarios;
6. stale-rate scenarios;
7. manual-override rules and audit implications;
8. reproducible worked examples;
9. minimum solver/integration data requirements;
10. explicit unresolved commercial-policy decisions.

### Worker-specific adversarial cases

Include cases involving:

- two equally plausible sources;
- a newer but less authoritative source;
- old contract rates reused on a new estimate;
- regional mismatch;
- unit mismatch;
- VAT-inclusive versus VAT-exclusive pricing;
- supplier quote expiration;
- negative/deflationary escalation;
- missing base date;
- manual override followed by estimate revision;
- rate source removed or superseded after estimate creation.

---

## Research 2 — R3-ONTOLOGY-001

### Title

**Canonical Quantity, Unit, Dimension, Stage, and Work-Classification Semantics**

### Objective

Convert the accepted Wave 2 ontology evidence into precise implementation-facing semantic options for Parser, Integration, and Solver contracts.

### Required research areas

Define and distinguish:

- observed quantity;
- derived quantity;
- measured quantity;
- gross quantity;
- net quantity;
- theoretical quantity;
- fabricated quantity;
- ordered/procured quantity;
- installed quantity;
- waste;
- allowance;
- loss;
- rounding;
- conversion;
- count;
- length;
- area;
- volume;
- mass;
- time;
- currency;
- compound units;
- source unit;
- canonical unit;
- display unit;
- normalization rule;
- work item classification;
- element classification;
- quantity stage;
- revision state.

### Required outputs

At minimum:

1. canonical terminology glossary;
2. candidate quantity-stage model;
3. unit/dimension matrix;
4. allowed and forbidden conversions;
5. ambiguity register;
6. cross-team field mapping;
7. examples of semantically invalid but numerically plausible transformations;
8. versioning rules;
9. migration/compatibility considerations;
10. unresolved ontology-policy decisions.

### Worker-specific adversarial cases

Include:

- equal numeric values with different dimensions;
- count-to-length corruption;
- millimeter/metre confusion;
- area and volume labels swapped;
- quantity stage collapsed;
- gross and net values accidentally interchanged;
- parser unit missing;
- canonical unit changed between software versions;
- display rounding altering stored calculation;
- compound-unit normalization.

---

## Research 3 — R3-RCBEAM-001

### Title

**RC Beam Measurement, Reinforcement Fabrication, and Procurement Decision Pack**

### Objective

Create the evidence reference for the project's first real Solver vertical slice: RC beam.

This is not a legacy-regression specification. It must define candidate normative behavior for the replacement architecture.

### Mandatory classification rule

Every substantive rule must be tagged as exactly one or more of:

```text
ENGINEERING_DESIGN_RULE
MEASUREMENT_RULE
ESTIMATING_CONVENTION
FABRICATION_RULE
PROCUREMENT_RULE
COMPANY_POLICY
PROJECT_ASSUMPTION
SOFTWARE_ARCHITECTURE_DECISION
```

Do not collapse these categories.

### Required research areas

Cover:

- beam concrete geometry;
- intersections and deductions;
- formwork measurement;
- longitudinal reinforcement;
- top/bottom bars;
- extra bars;
- stirrups/ties;
- clear cover;
- hooks;
- bends;
- anchorage;
- development length;
- laps;
- splice zones;
- couplers;
- bar marks;
- stock lengths;
- cut lengths;
- kerf;
- fabrication waste;
- offcuts;
- cutting-stock optimization;
- multi-diameter inventory;
- bundle/stock constraints;
- procurement rounding;
- infeasible cut handling;
- unresolved structural decisions;
- quantity-stage transitions.

### Required outputs

At minimum:

1. RC-beam rule classification register;
2. candidate formula/measurement book;
3. fabrication transformation model;
4. procurement transformation model;
5. at least one independently recomputable normative beam case;
6. boundary-case suite;
7. prohibited hidden defaults;
8. unresolved engineering-policy register;
9. solver input requirements;
10. traceability requirements from final BOQ line back to beam and source evidence.

### Worker-specific adversarial cases

Include:

- unsupported bar diameter;
- overlength bar;
- lap required but splice policy unknown;
- coupler alternative;
- different stock lengths;
- multiple diameters;
- reuse of offcuts;
- impossible cutting pattern;
- rounding policy changes;
- beam count greater than one;
- varying stirrup zones;
- bars with hooks/bends;
- conflicting schedule and detail information;
- missing cover;
- missing span;
- fabrication rule changed between estimate revisions.

---

## Research 4 — R3-BOUNDARY-001

### Title

**Parser-to-Solver Acceptance, Verification, Conflict, and Release-Risk Gates**

### Objective

Produce candidate governance and machine-readable behavior for deciding whether extracted construction facts may safely cross into Solver calculation.

### Governing starting rule

Until an explicit versioned automatic-acceptance policy is adopted:

```text
UNREVIEWED + solver-critical
→ REVIEW_REQUIRED
```

Research may propose alternatives but may not silently override this rule.

### Required research areas

Cover:

- observed versus derived fields;
- confidence;
- source quality;
- verification state;
- conflict state;
- missing state;
- manually confirmed state;
- reviewer identity;
- review timestamp;
- source localization;
- automatic acceptance;
- human review;
- rejection;
- correction;
- source revision changes;
- stale verification;
- parser disagreement;
- cross-sheet disagreement;
- release gates;
- blocker severity;
- risk thresholds;
- false-positive/false-negative tradeoffs.

### Required outputs

At minimum:

1. candidate state machine;
2. acceptance-policy options;
3. blocker matrix;
4. conflict-resolution matrix;
5. human-review trigger matrix;
6. stale-verification rules;
7. source-localization requirements;
8. integration contract requirements;
9. release-risk scenarios;
10. unresolved PM/policy decisions.

### Worker-specific adversarial cases

Include:

- high confidence with no source localization;
- low confidence but manually confirmed;
- manual confirmation with missing reviewer;
- manual confirmation with missing timestamp;
- two high-confidence conflicting values;
- drawing revision invalidating old confirmation;
- inferred unit;
- missing critical field;
- parser failure followed by fallback/sample value;
- verified value whose source sheet is superseded.

---

## Research 5 — R3-AUDIT-001

### Title

**Estimate Reproducibility, Revision, Lineage, and Audit Architecture Decision Pack**

### Objective

Define evidence-backed architecture options that allow an estimate to be reproduced and explained months or years after creation.

### Required research areas

Cover:

- immutable estimate snapshots;
- estimate revision identifiers;
- drawing/source revision identifiers;
- parser version;
- parser configuration;
- integration contract version;
- solver/formula version;
- measurement-policy version;
- procurement-policy version;
- rate-source version;
- rate effective date;
- manual override history;
- human verification history;
- change attribution;
- calculation lineage;
- deterministic reruns;
- retained inputs versus recomputed outputs;
- content hashing;
- audit events;
- correction/reversal events;
- estimate comparison;
- deleted/superseded source handling;
- provenance retention;
- reproducibility failure modes.

### Required outputs

At minimum:

1. candidate estimate-snapshot model;
2. audit-event model;
3. calculation-lineage model;
4. version-linking matrix;
5. manual-override lifecycle;
6. revision-comparison model;
7. deterministic-rerun requirements;
8. storage-versus-recompute decision matrix;
9. failure-recovery scenarios;
10. minimum evidence required to answer "where did this BOQ number come from?"

### Worker-specific adversarial cases

Include:

- source drawing removed after estimate approval;
- rate database updated;
- formula version changed;
- manual override later reversed;
- parser model changed;
- same drawing reprocessed with new parser;
- quantity matches by coincidence but provenance differs;
- user edits a verified value;
- old estimate reopened after policy change;
- partially reproducible legacy estimate.

---

## Research 6 — R3-STANDARDS-001

### Title

**Construction Standards, Philippine Source Authority, and Evidence-Reliance Matrix**

### Objective

Build a reusable source-authority framework so future research and implementation decisions can distinguish authoritative evidence from convenient references.

### Required research areas

Research applicable categories of:

- Philippine government construction references;
- DPWH/public works references where relevant;
- laws/regulations where relevant;
- material/structural standards;
- measurement standards;
- estimating references;
- cost/rate references;
- manufacturer data;
- academic references;
- professional guidance;
- project specifications;
- contract documents;
- protected/licensed standards;
- secondary summaries;
- superseded editions;
- conflicting editions;
- regional applicability.

### Required outputs

At minimum:

1. source-authority hierarchy;
2. source register schema;
3. edition/effective-date rules;
4. supersession rules;
5. conflict-resolution procedure;
6. protected/licensed-source handling rules;
7. citation/evidence requirements;
8. applicability matrix;
9. source-quality scoring or classification proposal;
10. explicit limitations where source text cannot legally or practically be embedded in project artifacts.

### Worker-specific adversarial cases

Include:

- official source versus newer secondary summary;
- two standards with overlapping scope;
- superseded standard still used by project specification;
- protected standard with no redistributable text;
- manufacturer recommendation conflicting with project specification;
- national reference not applicable to local/project condition;
- undated web material;
- dead source link;
- source updated after estimate approval.

---

# 6. Mandatory Wave 3 evidence package structure

Every worker package must contain, at minimum:

```text
README.md
EXECUTIVE_FINDINGS.md
DECISION_MATRIX.md
SOURCE_REGISTER.csv
SOURCE_NOTES/
EVIDENCE/
WORKED_EXAMPLES/
ADVERSARIAL_CASES/
OPEN_DECISIONS.md
CONTRADICTION_REVIEW.md
IMPLEMENTATION_IMPLICATIONS.md
SELF_REVIEW.md
PROCESS_LOG.md
SHA256SUMS.txt
```

Where appropriate, also include:

```text
DATASETS/
ORACLES/
VALIDATORS/
SCHEMAS/
DIAGRAMS/
```

The exact structure may vary by task, but equivalent evidence must exist.

---

# 7. Five-hour substantive-work design target

Each worker task must be designed so that a serious completion normally requires at least about five hours of focused effort.

This is an **assignment-depth target**, not a wall-clock pass/fail threshold.

## Prohibited behavior

Workers must not:

- idle to accumulate time;
- pad reports;
- duplicate citations;
- generate cosmetically different cases;
- create meaningless bulk data;
- split one source into many pseudo-sources;
- treat validator success as independent proof;
- claim research depth from file count alone.

## Required process evidence

`PROCESS_LOG.md` must record meaningful stages such as:

```text
scope decomposition
source discovery
primary-source verification
source comparison
worked-example construction
independent recalculation
adversarial-case design
contradiction review
decision synthesis
self-review
final package integrity check
```

Timestamps may be recorded, but elapsed time itself does not prove quality.

If a worker returns dramatically faster than the designed effort envelope, the TL must perform an adversarial review focused on whether required independent work was actually completed.

---

# 8. Backjob-reduction protocol

Wave 3 should reduce avoidable correction loops by moving quality checks earlier.

No worker package should reach TL review until the worker completes the following pre-handoff gate.

## Worker pre-handoff gate

The worker must verify:

### Scope

- every required research area is addressed;
- every required output exists;
- no production implementation was performed;
- unresolved policy decisions are explicitly separated from recommendations.

### Evidence

- source register is complete;
- primary/official sources are preferred where available;
- source purpose and applicability are stated;
- source edition/date is captured where relevant;
- unsupported claims are marked as such.

### Semantic diversity

- case counts are based on materially distinct problem bodies;
- identifiers, labels, cosmetic dates, and narrative changes do not create fake uniqueness;
- subset labels actually satisfy subset semantics.

### Numerical/logical verification

- worked examples are independently recomputable;
- independent calculations do not simply call the same implementation being checked;
- assumptions are explicit;
- units and dimensions are checked.

### Validators

- validators run from a clean extraction;
- validators are path-portable;
- validators do not modify sealed evidence;
- pre/post file-tree integrity is checked;
- worker validators are described as self-consistency tools unless a genuinely independent oracle exists.

### Contradictions

- internal contradictions are reviewed;
- cross-source contradictions are recorded;
- conflicts with accepted Wave 2 evidence are identified;
- the worker does not silently reconcile conflicting authorities.

### Implementation usefulness

- Parser implications are identified where relevant;
- Solver implications are identified where relevant;
- Integration implications are identified where relevant;
- PM/policy decisions are separated from technical facts;
- minimum machine-readable data requirements are proposed where relevant.

### Integrity

- package manifest/checksums pass;
- no temporary files or tracked bytecode are present;
- no validator mutates sealed evidence;
- all referenced files exist.

`SELF_REVIEW.md` must contain the completed gate and identify any remaining nonblocking limitations.

---

# 9. Lessons from Wave 2 that become Wave 3 hard preflight checks

The following Wave 2 QA findings are now explicit Wave 3 prevention controls.

## 9.1 Semantic-count inflation

Wave 2 required independent recounting because labels and nominal case counts could overstate materially distinct cases.

Wave 3 rule:

```text
CASE COUNT ≠ DISTINCT CASE COUNT
```

Workers and TL must evaluate materially distinct problem bodies.

## 9.2 Subset-label correctness

Wave 2 QA found four cases labeled as multi-diameter that contained only one demand diameter.

Wave 3 rule:

A case may only satisfy a specialized subset gate if its actual material inputs satisfy the subset definition.

## 9.3 Validator portability

Wave 2 exposed validator path/root defects.

Wave 3 rule:

Every validator must be executed from a clean extracted package using documented entry points.

## 9.4 Sealed-evidence mutation

Wave 2 exposed validator-induced mutation risk.

Wave 3 rule:

Run complete pre/post file-tree hashing around validator execution.

A validator that changes sealed evidence fails the preflight gate.

## 9.5 Validator independence

Wave 2 QA correctly treated worker validators as reproducibility/self-consistency tools, not independent oracles.

Wave 3 rule:

A worker-authored validator cannot self-certify methodology correctness.

Where a claim requires an oracle, use a separately derived calculation, independently specified rule set, or external/primary evidence.

## 9.6 Policy versus evidence

Wave 2 QA explicitly did not adopt rate policy, structural splice/coupler policy, procurement objectives, contingency/risk appetite, production schemas, or protected-standard interpretations.

Wave 3 rule:

Every implementation-facing recommendation must identify its authority class and adoption owner.

---

# 10. Research TL responsibilities

The Research TL must not simply concatenate six worker outputs.

The TL owns synthesis.

The TL must:

1. verify worker packages against their assignment gates;
2. reject superficial completion before QA;
3. independently challenge case diversity;
4. inspect process evidence for implausibly shallow execution;
5. verify key primary sources;
6. rerun representative calculations;
7. rerun validators from clean copies;
8. inspect pre/post integrity;
9. reconcile contradictions across workers;
10. identify duplicated or conflicting terminology;
11. create a cross-research dependency map;
12. separate facts from candidate policies;
13. identify decisions ready for PM adoption;
14. identify decisions that still require Solver/Parser/Integration testing;
15. identify decisions requiring Product Owner/business judgment;
16. produce a concise executive decision register.

The TL should prefer returning a worker internally before formal QA if an obvious gate is missing.

The goal is fewer downstream QA backjobs, not fewer corrections at any cost.

---

# 11. Required TL synthesis outputs

The final TL package should contain at minimum:

```text
INDEPENDENT_RESEARCH_WAVE3_TECH_REVIEW_R1.zip

README.md
TECH_REVIEW.md
CROSS_RESEARCH_DECISION_REGISTER.md
CROSS_RESEARCH_CONTRADICTIONS.md
ADOPTION_CANDIDATES.md
DEFERRED_POLICY_DECISIONS.md
SOLVER_IMPLICATIONS.md
PARSER_IMPLICATIONS.md
INTEGRATION_IMPLICATIONS.md
SOURCE_AUTHORITY_SUMMARY.md
WORKER_DISPOSITION.md
PROCESS_DEPTH_REVIEW.md
EVIDENCE_INDEX.md
SHA256SUMS.txt
```

Target handoff state:

```text
READY_FOR_RESEARCH_QA
```

---

# 12. Worker disposition vocabulary

Use:

```text
ACCEPTED
ACCEPTED_WITH_NOTES
RETURNED_FOR_CORRECTION
BLOCKED_BY_EVIDENCE
BLOCKED_BY_POLICY_INPUT
```

Do not use vague labels such as "done" where the technical disposition matters.

---

# 13. Speedrun control

Fast work is not automatically bad.

However, if a worker returns in a time that appears inconsistent with the required source review, independent verification, adversarial-case construction, and synthesis, the TL must answer:

```text
What independent work was actually performed?
Which primary sources were verified?
Which calculations were independently recomputed?
Which cases were materially distinct?
Which contradictions were challenged?
Which assumptions were exposed?
What could not have been produced by merely transforming prior text?
```

If the evidence cannot answer those questions, return the package before QA.

The TL must not manufacture a backjob solely because the clock was short. The issue is insufficient demonstrated work, not elapsed time itself.

---

# 14. Definition of a strong first-pass worker handoff

A strong Wave 3 worker handoff should allow the TL to spend its time on:

```text
cross-worker synthesis
contradiction resolution
adoption readiness
dependency analysis
```

rather than:

```text
finding missing files
repairing counts
discovering fake case diversity
fixing path assumptions
finding validator mutation
asking for basic source provenance
separating policy from fact after the fact
```

That is the primary backjob-reduction goal.

---

# 15. PM acceptance philosophy for Wave 3

Wave 3 will not be accepted merely because:

- all six workers returned;
- validators are green;
- case-count thresholds are met;
- reports are long;
- many citations exist;
- the TL says the package is complete.

PM will expect evidence that the wave materially reduces uncertainty for the next product decisions.

The strongest Wave 3 outcome is a set of research artifacts that lets Solver, Parser, and Integration implement or test explicit candidate rules without guessing where those rules came from.

---

# 16. Current authorization

```text
RESEARCH WAVE 3
PM_RESEARCH_AUTHORIZED

Research 1: R3-COST-001
Research 2: R3-ONTOLOGY-001
Research 3: R3-RCBEAM-001
Research 4: R3-BOUNDARY-001
Research 5: R3-AUDIT-001
Research 6: R3-STANDARDS-001

Current owner after forwarding:
Research TL

Next action:
Research TL assigns/briefs six workers and enforces the Wave 3 pre-handoff gates.

Next formal gate:
Research TL technical review
→ Research QA
→ PM
```

---

# 17. PM instruction to Research TL

Proceed with Wave 3.

Optimize for **substantive evidence per worker-hour**, not raw speed.

The approximately five-hour design target exists to ensure that the assignments contain enough real research, independent verification, adversarial testing, and implementation-facing synthesis to justify the worker slot.

Do not slow workers artificially.

Do make shallow completion impossible to pass.

And move preventable QA corrections upstream by requiring the worker pre-handoff gate before TL review.
