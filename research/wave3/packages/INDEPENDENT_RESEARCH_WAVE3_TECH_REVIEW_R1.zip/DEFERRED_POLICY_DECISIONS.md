# Deferred Policy Decisions

Research does not have authority to decide these.

## Commercial / rate policy
- rate-source precedence and eligibility hierarchy edges;
- DPWH/public-rate role for private projects;
- VAT/tax presentation basis;
- freight/delivery canonical basis;
- FX date convention;
- index selection and escalation formula;
- stale-rate windows;
- override authority, expiry and revision carry-forward;
- composite versus elemental substitution policy.

## Measurement / quantity-surveying policy
- governing measurement regime;
- beam/slab intersection ownership and deductions;
- trade-specific waste/allowance factors;
- rounding timing and rules;
- payment versus procurement quantity transitions.

## Engineering / detailing policy
- governing structural code/project authority;
- clear cover, anchorage, development length, lap/splice zones;
- coupler approval;
- BBS/shape-code regime;
- any design response to missing structural information.

## Procurement / company policy
- optimization primary objective;
- reusable-offcut threshold and valuation;
- cross-job reuse rules;
- stock-length preferences;
- kerf/process allowances;
- bundle/MOQ handling.

## Parser / human verification policy
- reviewer authority matrix;
- automatic acceptance policy;
- field-specific confidence thresholds;
- document/source precedence;
- warning tolerance;
- review-expiry windows;
- authorized override semantics.

## Audit / security / retention policy
- retention periods;
- legal holds;
- digital signature/trusted timestamp requirements;
- canonical manifest encoding;
- target reproducibility tier;
- archive technology;
- PII handling in append-only events;
- branching/merge workflow.

## Standards / source policy
- project contract hierarchy;
- licensed-standard storage/access;
- handling unknown effective dates;
- errata/amendment adoption;
- fresh-lookup behavior for mutable current-edition metadata.
