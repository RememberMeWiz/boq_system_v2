# Cross-Research Decision Register

The statuses below are Research TL synthesis labels, not PM adoption.

| ID | Candidate decision | Converging research | TL classification | Next owner |
|---|---|---|---|---|
| CRD-01 | Preserve immutable raw evidence and create new derived/transformed records rather than mutating source facts | R1, R2, R4, R5, R6 | `ADOPTION_CANDIDATE` | Integration / PM architecture |
| CRD-02 | Use typed quantity stages and immutable stage transitions | R2, R3, R5 | `ADOPTION_CANDIDATE` | Solver + Integration |
| CRD-03 | Separate source/display/canonical units and prevent display rounding from feeding calculations | R2 | `ADOPTION_CANDIDATE` | Integration + Solver |
| CRD-04 | Block solver-critical missing/conflicting/unsupported/sample-default data | R1, R3, R4, R5 | `ADOPTION_CANDIDATE` | Parser + Integration + Solver |
| CRD-05 | Treat parser confidence as orthogonal to solver eligibility | R4, supported by R2/R6 provenance model | `ADOPTION_CANDIDATE` | Parser + Integration |
| CRD-06 | Require source identity, hash/revision and typed localization for solver-critical claims | R4, R5, R6 | `ADOPTION_CANDIDATE` | Parser + Integration |
| CRD-07 | Make derived claims inherit parent eligibility and method version | R2, R4, R5 | `ADOPTION_CANDIDATE` | Integration |
| CRD-08 | Model rates as immutable observations → eligibility → normalization → explicit resolution → snapshot | R1, R5, R6 | `ADOPTION_CANDIDATE` | Solver + Integration |
| CRD-09 | Use eligibility before rate/source precedence | R1, R6 | `ADOPTION_CANDIDATE` | Pricing/Integration |
| CRD-10 | Distinguish current source state from project-governing/frozen state | R1, R5, R6 | `ADOPTION_CANDIDATE` | Integration + Audit |
| CRD-11 | Preserve effective/valid time and recorded/knowledge time | R1, R5, R6 | `ADOPTION_CANDIDATE` | Data/Audit |
| CRD-12 | Use immutable estimate revision identity and dependency manifest | R5, supported by R1/R4/R6 | `ADOPTION_CANDIDATE` | Architecture / Integration |
| CRD-13 | Retain originally approved outputs; reruns become separately identified verification runs | R5 | `ADOPTION_CANDIDATE` | Audit architecture |
| CRD-14 | Use claim-specific source precedence plus hard applicability/access gates, not one scalar authority score | R6, supported by R1/R4 | `ADOPTION_CANDIDATE` | Integration + PM |
| CRD-15 | Treat metadata-only protected standards as insufficient for inaccessible clause-level claims | R3, R6 | `ADOPTION_CANDIDATE` | QA + Domain owners |
| CRD-16 | Use RC beam as first replacement-architecture vertical slice | R2, R3, R4, R5 | `TEST_CANDIDATE` | Solver + Integration |
| CRD-17 | No automatic standard-edition upgrade or current-rate substitution during historical rerun | R1, R5, R6 | `ADOPTION_CANDIDATE` | Audit + Pricing |
| CRD-18 | Use field-ledger derived release state rather than a coarse session READY token | R4, supported by R2/R5 | `TEST_CANDIDATE` | Integration |
| CRD-19 | Consider hybrid content-addressed artifacts + immutable manifest + append-only audit log | R5, supported by R6 | `IMPLEMENTATION_CANDIDATE` | Architecture |
| CRD-20 | Do not embed procurement waste/allowance into measured quantity identity | R1, R2, R3 | `ADOPTION_CANDIDATE` | Solver + Commercial |
