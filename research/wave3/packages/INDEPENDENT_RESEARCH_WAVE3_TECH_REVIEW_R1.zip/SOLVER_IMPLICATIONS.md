# Solver Implications

Research only. No production change is authorized.

## Candidate input invariants
Solver-facing records should carry:
- stable semantic identity;
- quantity kind and physical dimension;
- source/canonical unit;
- quantity stage;
- source/claim provenance;
- verification/eligibility state;
- revision identity;
- transformation/formula version;
- policy version where applicable.

## Hard blockers
Candidate solver behavior should reject or isolate:
- missing solver-critical geometry;
- unsupported unit/diameter/grade;
- open source conflict;
- sample/default-substituted critical facts;
- stale/invalid verification;
- missing parent of a derived claim;
- missing project-authorized structural/detailing decision.

## RC beam vertical slice
The beam candidate should separate:
1. measured concrete/formwork quantity;
2. approved reinforcement fabrication demand;
3. controlled theoretical mass;
4. procurement stock/offcut transformation;
5. BOQ presentation.

No lap, cover, hook, development length, splice or coupler rule should be invented by procurement logic.

## Pricing
The Solver should consume an approved or unresolved rate-resolution record, not a naked current price.
Missing price should not erase physical quantity.

## Regression candidates
- unsupported diameter hard fail;
- missing cover/span blocker;
- conflicting schedule/detail blocker;
- no hidden geometry fallback;
- stock/mass conservation;
- multi-diameter inventory separation;
- historical rerun with pinned rate/source state;
- quantity-stage non-overwrite invariants.
