# Parser Implications

Research only. No production change is authorized.

## Candidate claim contract

Solver-critical parser claims should preserve:
- observed versus derived state;
- exact source revision/hash;
- typed source localization;
- extracted lexical value and unit;
- canonicalized candidate value/unit without erasing source evidence;
- confidence as separate metadata;
- conflict state;
- review state;
- reviewer/review timestamp when applicable;
- parent claim IDs for derived values.

## Baseline release rule

Until PM adopts a versioned automatic policy:

```text
UNREVIEWED + solver-critical
→ REVIEW_REQUIRED
```

High confidence does not override:
- missing localization;
- wrong/superseded source;
- conflict;
- unsupported unit;
- fallback/sample substitution;
- missing provenance.

## Revision behavior

Review should invalidate through dependency changes, not merely because the calendar advanced.
Historical reruns retain the source/review state that belonged to the historical estimate.

## Standards/specification extraction

When a drawing/specification cites a standard, preserve exact tokens:
- title/code;
- year/edition;
- suffix/amendment/errata where visible;
- section/clause locator where available;
- source location.

Do not guess “latest edition” when the source omitted it.
