# Research QA Review Instructions

This package is the Research TL Wave 3 technical synthesis.

Final TL state:

`READY_FOR_RESEARCH_QA`

Please independently test the claims rather than accepting TL or worker validators as authority.

Priority QA challenges:
1. semantic distinctness of representative worker corpora;
2. independent recomputation of RC-beam, rate, dimensional and audit traces;
3. field-state/eligibility logic;
4. Research 6 corrected source identities and mutable-source provenance;
5. package integrity and clean validator behavior;
6. cross-research policy/engineering/commercial boundaries;
7. whether adoption candidates are genuinely supported across workers;
8. whether any worker recommendation has been silently promoted into project policy.

Preserve the PM boundary:

```text
Production changes: NOT AUTHORIZED
Methodology adoption: NOT AUTOMATIC
Commercial policy adoption: NOT AUTOMATIC
Structural/engineering design decisions: NOT AUTOMATIC
Repository Steward action: SEPARATE PM DECISION
```
