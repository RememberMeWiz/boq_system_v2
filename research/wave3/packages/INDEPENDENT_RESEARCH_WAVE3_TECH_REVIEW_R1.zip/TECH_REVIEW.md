# Independent Research Wave 3 Technical Review R1

## Final state

`READY_FOR_RESEARCH_QA`

The six Wave 3 packages were reviewed under the PM's speedrun-control and backjob-reduction rules.

The TL did not accept worker validators as proof of methodology. Review included:
- clean extraction;
- path-portable validator/oracle reruns;
- pre/post complete-tree integrity comparison;
- semantic-body recounts;
- independent numerical/logical recomputation;
- primary-source spot checks;
- repository claim verification;
- process-depth inspection;
- cross-worker contradiction and dependency synthesis.

Research 6 was internally returned three times for source-identity/provenance defects before acceptance.

## Overall technical result

Wave 3 materially improves implementation readiness over Wave 2.

The workers converge on a common architecture direction:

```text
immutable source evidence
→ typed observed / derived claim
→ field-level verification and eligibility state
→ canonical unit / quantity-stage transformation ledger
→ deterministic solver calculation
→ fabrication / procurement transformation where applicable
→ provenance-backed rate resolution
→ immutable estimate revision snapshot
→ audit / comparison / risk layers
```

The research does **not** authorize the project to adopt every rule in that chain. It separates implementable technical invariants from policy/engineering/commercial decisions that still require owners.

## Strongest technical conclusions

1. Solver-critical missing, conflicting, unsupported or sample/default-substituted facts should fail closed rather than be repaired by hidden assumptions.
2. Parser confidence is not solver validity. Eligibility should be field-level and provenance-aware.
3. Quantity stage is part of semantic identity. Measured, fabricated, procured and BOQ-presented values must not overwrite one another.
4. Raw rate observations and source evidence should remain immutable; normalization and selection should be explicit versioned activities.
5. Historical estimates require both effective/valid time and recorded/knowledge time.
6. Approved estimate revisions require immutable identities plus pinned source/parser/integration/solver/policy/rate dependencies.
7. “Current” and “governing” are different states for standards, rates and source documents.
8. Protected standard metadata can establish identity/version/status but cannot prove inaccessible clause-level requirements.
9. RC beam is ready to serve as a first replacement-architecture test vertical only if structural/detailing/measurement choices remain explicit inputs or blockers.
10. Research outputs are candidate contracts and test references, not production authority.

## Fast-completion finding

The six packages returned faster than the intended substantive-effort envelope, so the TL applied adversarial review.

The evidence showed material independent work rather than merely transformed prior prose:
- source discovery and first-party verification;
- explicit rejected/inaccessible source handling;
- independent oracles/recalculations;
- materially distinct adversarial corpora;
- repository-pinned findings;
- competing architecture/policy options;
- contradiction registers;
- clean package/integrity evidence.

Fast completion therefore remains a scrutiny note, not a rejection basis.
