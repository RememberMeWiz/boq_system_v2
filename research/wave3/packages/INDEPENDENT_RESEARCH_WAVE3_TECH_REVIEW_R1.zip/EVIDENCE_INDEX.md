# Evidence Index

## Worker packages

Byte-preserved under `workers/`:

- Research 1: `RESEARCH_1_R3_COST_001.zip`
- Research 2: `RESEARCH_2_R3_ONTOLOGY_001.zip`
- Research 3: `RESEARCH_3_R3_RCBEAM_001.zip`
- Research 4: `RESEARCH_4_R3_BOUNDARY_001.zip`
- Research 5: `RESEARCH_5_R3_AUDIT_001.zip`
- Research 6 final: `RESEARCH_6_R3_STANDARDS_001_CORRECTION_R3.zip`

Hashes are recorded in `references/INPUT_AND_CORRECTION_HASHES.json`.

## TL evidence

- `evidence/validation_runs/TL_CLEAN_EXTRACTION_VALIDATION.json`
  - validator/oracle commands;
  - exit codes;
  - read-only tree behavior.

- `evidence/independent_checks/TL_SEMANTIC_RECOUNT.json`
  - body-level depth-gate recounts.

- `evidence/independent_checks/TL_INDEPENDENT_RECALCULATIONS.json`
  - independent numerical/logical sampling.

- `evidence/correction_closure/RESEARCH_6_CORRECTION_CLOSURE.md`
  - three-stage Research 6 source-provenance correction history.

## Synthesis outputs

- `CROSS_RESEARCH_DECISION_REGISTER.md`
- `CROSS_RESEARCH_CONTRADICTIONS.md`
- `ADOPTION_CANDIDATES.md`
- `DEFERRED_POLICY_DECISIONS.md`
- `SOLVER_IMPLICATIONS.md`
- `PARSER_IMPLICATIONS.md`
- `INTEGRATION_IMPLICATIONS.md`
- `SOURCE_AUTHORITY_SUMMARY.md`
- `PROCESS_DEPTH_REVIEW.md`
- `WORKER_DISPOSITION.md`

## Governance reference

- `references/RESEARCH_WAVE3_TL_DIRECTIVE_R1.md` when available.

## QA scope recommendation

Research QA should independently challenge:
- TL semantic recounts;
- worker/source integrity;
- representative independent calculations;
- source-authority corrections;
- cross-research policy separation;
- whether implementation candidates are actually supported by the worker evidence.

QA should not treat `READY_FOR_RESEARCH_QA` as methodology or production adoption.
