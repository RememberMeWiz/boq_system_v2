# Adoption Candidates

These are candidates for PM consideration after Research QA. None are adopted by this package.

## High-confidence cross-worker candidates

1. **Fail closed on solver-critical deterministic defects.**
   Missing, conflicting, unsupported, invalid, sample/default-substituted or provenance-incomplete critical inputs should not be silently repaired.

2. **Immutable evidence + transformation lineage.**
   Preserve source observations/claims and create new versioned derived records for conversions, allowances, normalization, fabrication, procurement and pricing.

3. **Typed quantity stages.**
   Separate measured, theoretical, fabricated, procured and BOQ presentation quantities.

4. **Versioned unit/dimension semantics.**
   Preserve source unit, canonical unit, quantity kind, physical dimension and display unit independently.

5. **Field-level parser eligibility.**
   Keep confidence separate from `BLOCKED / REVIEW_REQUIRED / ELIGIBLE / NOT_APPLICABLE`-style solver readiness.

6. **Exact provenance binding for review.**
   Bind review to claim/value, source hash/revision, reviewer and review time.

7. **Bitemporal historical evidence.**
   Preserve effective/valid time and recorded/knowledge time for rates, source states and policy decisions.

8. **Immutable estimate revision manifest.**
   Pin source, parser, integration, formula/solver, policy, rate, override and verification dependencies.

9. **No silent auto-upgrade.**
   Do not silently replace historical rates, standard editions, formulas or policies with current versions.

10. **Claim-specific source reliance.**
    Authority, applicability, project incorporation, lifecycle state and access sufficiency are independent gates.

11. **Protected-source claim ceiling.**
    Metadata can prove identity/version/status but not inaccessible clause content.

12. **RC beam vertical-slice test contract.**
    Use RC beam as the first integrated candidate with explicit blockers for unresolved engineering/detailing inputs.

## Recommended adoption sequence

```text
semantic/data invariants
→ parser eligibility contract
→ immutable lineage/snapshot primitives
→ RC beam vertical-slice tests
→ rate provenance/normalization interface
→ policy-specific choices
```

This order minimizes the risk that business or engineering policy becomes accidentally baked into low-level data structures.
