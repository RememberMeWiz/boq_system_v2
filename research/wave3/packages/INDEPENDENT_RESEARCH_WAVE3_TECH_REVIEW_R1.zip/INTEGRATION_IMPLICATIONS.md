# Integration Implications

Research only. No production change is authorized.

Integration is the main convergence point of Wave 3.

## Candidate core records

### Claim / observation
- stable ID;
- source identity/revision/hash;
- localization;
- lexical and canonical value/unit;
- quantity kind/dimension/stage;
- confidence;
- verification/eligibility state;
- conflict group;
- parent lineage.

### Transformation event
- input IDs;
- output ID;
- transformation type;
- method/rule/version;
- policy version;
- actor or automated process;
- timestamp;
- rounding rule;
- evidence/reason code.

### Source record
- exact document identity;
- issuer/authority class;
- applicability;
- lifecycle status and checked-at time;
- edition/amendment/errata;
- access/claim ceiling;
- project incorporation/freeze state;
- lawful snapshot/hash reference.

### Estimate revision manifest
- immutable revision ID;
- parent revision;
- source set;
- parser/model/config versions;
- integration contract;
- solver/formula versions;
- measurement/procurement/rate policy versions;
- selected rate records;
- overrides/reviews;
- output artifact hashes.

## Candidate release composition

Session/estimate readiness should be derived from:
- field-level eligibility ledger;
- source/manifest integrity;
- unit/stage invariants;
- deterministic solver reconciliation;
- unresolved conflict/blocker state;
- downstream release requirements.

A coarse `READY` token should not be trusted without its underlying evidence ledger.
