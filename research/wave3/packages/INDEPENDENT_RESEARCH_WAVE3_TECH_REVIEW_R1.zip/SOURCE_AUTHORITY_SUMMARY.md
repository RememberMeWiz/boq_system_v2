# Source Authority Summary

## Cross-wave source principle

Wave 3 supports a claim-specific source model rather than a single prestige ranking.

A useful source decision requires separate evaluation of:
- identity;
- issuer/authority class;
- jurisdiction/project applicability;
- purpose;
- edition/version;
- publication/effective time;
- lifecycle state;
- project incorporation/freeze state;
- access/redistribution rights;
- claim-support ceiling;
- conflict/supersession relationships.

## Research 6 final register

Final corrected Research 6 register contains:
- 73 source records;
- 73 marked primary/first-party;
- 35 Philippine public-authority records;
- dedicated authority-conflict, supersession, protected-source, applicability and mutable-link corpora.

The TL returned Research 6 three times because source-identity reliability is the central deliverable of that workstream.

## Protected standards

Official publisher metadata can establish document identity, edition, status and discovery information.
It cannot support inaccessible clause-level technical claims unless the project has authorized text access.

## Mutable metadata

The ASTM C94 correction sequence is retained as a concrete example:
different first-party/search snapshots can expose different “current” edition states at different observation times.

The architectural conclusion is stronger than the particular edition:
- store `status_checked_at`;
- preserve prior source-state observations;
- do not silently auto-upgrade;
- fresh-check at adoption/use time or use a project-frozen edition.

## Philippine applicability

Government/public references must still be evaluated by scope:
- statutory/regulatory;
- DPWH/public-works-specific;
- wage-order region/classification;
- index purpose/geography;
- project contract incorporation.

“Official” does not automatically mean “the price/rule that controls this estimate.”
